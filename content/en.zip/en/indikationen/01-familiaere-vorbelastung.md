---
title: "Familiäre Vorbelastung"
icon: "familiar_face_and_zone"
description: "Menschen mit einer genetischen Prädisposition zum Beispiel für Krebs oder Aneurysmen möchten sicher gehen, dass bei Ihnen noch alles in Ordnung ist."
weight: 1
---
