---
title: "Basel"
date: 2025-01-25
image: "img/standorte/basel.webp"
fullimage: "img/standorte/_basel.webp"
---
Dies ist eine Beispielbeschreibung für Projekt 3. Eine kurze Beschreibung des Projekts und seiner Highlights.
