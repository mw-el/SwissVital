---
title: "Zürich"
date: 2025-01-25
image: "img/standorte/zurich.webp"
fullimage: "img/standorte/_zurich.webp"
---
Dies ist eine Beispielbeschreibung für Projekt 1. Eine kurze Beschreibung des Projekts und seiner Highlights.
