---
{{/*
  partials/full-bg.html
  --------------------
  This partial generates a full-background section with configurable settings.
  - Uses an outer `.sv-bg-canvas` as the background layer, which can be:
    - A background image (including gradients) if `background_image` is set.
    - A background color with a foreground image if `image` is set.
  - An inner `.sv-bg-content` holds the text and buttons.
  - Supports user-defined text alignment and color settings.
  - Handles responsive adjustments for various screen sizes.
  - Uses `.sv-spacer` to create screen-dependent spacing between headline, main text, and button.
  - The image is dynamically cropped (zoomed) to match the height of the content.
  - Supports combining a background image with a foreground image when using a split layout.
  - Ensures that on small screens, the image moves between the headline and the main content.
  - Crops the image to a square (10% from top, 90% from bottom) when it stacks on small screens.
  - Provides full customization for primary and secondary buttons, ensuring proper contrast.
  - Enables rendering HTML in the front matter values and content body.
  - Allows dynamic button placement under the image or main content, ensuring correct spacing.
  - All font sizes, spacing, and paddings use `clamp()` for optimal responsiveness.
*/}}

<style>
  /* General styles */
  .sv-bg-canvas {
    width: 100%;
    padding: clamp(1rem, 3vw, 4rem);
    box-sizing: border-box;
  }

  .sv-bg-grid {
    display: flex;
    gap: clamp(1rem, 2vw, 2.5rem);
    align-items: stretch;
  }

  /* Headline styling */
  .sv-bg-content h2 {
    font-size: clamp(1.5rem, 4vw, 3rem);
    margin-bottom: clamp(0.5rem, 2vw, 2rem);
  }

  /* Content text styling */
  .sv-bg-content p {
    font-size: clamp(1rem, 2vw, 1.5rem);
  }

  /* Spacer to maintain dynamic spacing */
  .sv-spacer {
    margin: clamp(0.5rem, 2vw, 2rem) 0;
  }

  /* Button styling */
  .sv-btn {
    font-size: clamp(0.875rem, 1.5vw, 1.25rem);
    padding: clamp(0.5rem, 1vw, 1rem) clamp(1rem, 2vw, 2rem);
    border-radius: 5px;
    text-decoration: none;
    display: inline-block;
  }

  .sv-btn-secondary {
    border: 1px solid;
  }

  /* Responsive behavior - Stacked layout on smaller screens */
  @media (max-width: 768px) {
    .sv-bg-grid {
      flex-direction: column;
    }
    .sv-grid-image {
      width: 100%;
      height: clamp(200px, 50vw, 400px);
      overflow: hidden;
    }
    .sv-grid-image img {
      height: 100%;
      object-fit: cover;
      object-position: top 10%; /* Crops 10% from the top, 90% from the bottom */
    }
  }
</style>

{{/* Retrieve values from front matter */}}
{{ $bgImage := .Params.background_image }}
{{ $fgImage := .Params.image }}
{{ $bgColor := .Params.background_color | default "#ffffff" }}
{{ $textColor := .Params.text_color | default "#222" }}
{{ $buttonPlacement := .Params.button_placement | default "content" }}

{{/* Primary Button */}}
{{ $primaryBtnBg := .Params.primary_button_background | default "#ff6600" }}
{{ $primaryBtnText := .Params.primary_button_text_color | default "#ffffff" }}
{{ $primaryBtnBorder := .Params.primary_button_border | default $primaryBtnBg }}
{{ $primaryBtnLink := .Params.primary_button_link | default "#" }}
{{ $primaryBtnLabel := .Params.primary_button_text | default "Mehr erfahren" }}

{{/* Secondary Button */}}
{{ $secondaryBtnBg := .Params.secondary_button_background | default $primaryBtnText }}
{{ $secondaryBtnText := .Params.secondary_button_text_color | default $primaryBtnBg }}
{{ $secondaryBtnBorder := .Params.secondary_button_border | default $primaryBtnText }}
{{ $secondaryBtnLink := .Params.secondary_button_link }}
{{ $secondaryBtnLabel := .Params.secondary_button_text }}

{{ $headlineAlign := .Params.headline_alignment | default "center" }}
{{ $bodyTextAlign := .Params.body_text_alignment | default "center" }}
{{ $buttonAlign := .Params.button_alignment | default "center" }}
{{ $gridLayout := .Params.grid_layout | default "c1/1" }}

<section class="sv-section sv-full-bg">
  <div class="sv-bg-canvas" style="{{ if $bgImage }}background-image: {{ $bgImage }};{{ else }}background-color: {{ $bgColor }};{{ end }}">
    
    <div class="sv-bg-grid">
      <div class="sv-grid-content" style="flex: 2; text-align: {{ $bodyTextAlign }}; color: {{ $textColor }};">
        <h2 style="text-align: {{ $headlineAlign }};">{{ .Title }}</h2>
      </div>
      
      {{ if eq $gridLayout "i3/5, c2/5" }}
        <div class="sv-grid-image" style="flex: 3; overflow: hidden; display: flex; align-items: center;">
          {{ if $fgImage }}
            <img src="{{ $fgImage }}" alt="Grid Image">
          {{ end }}
        </div>
      {{ end }}
      
      <div class="sv-grid-content" style="flex: 2; text-align: {{ $bodyTextAlign }}; color: {{ $textColor }};">
        <div class="sv-spacer"></div>
        <div>{{ .Content | safeHTML }}</div>
      </div>
    </div>
    
    {{ if eq $buttonPlacement "image" }}
      <div class="sv-spacer"></div>
    {{ end }}
    <div class="sv-buttons" style="text-align: {{ $buttonAlign }};">
      <a href="{{ $primaryBtnLink }}" class="sv-btn" style="background-color: {{ $primaryBtnBg }}; color: {{ $primaryBtnText }}; border: 1px solid {{ $primaryBtnBorder }};">{{ $primaryBtnLabel }}</a>
      {{ if $secondaryBtnLabel }}
        <a href="{{ $secondaryBtnLink }}" class="sv-btn sv-btn-secondary" style="background-color: {{ $secondaryBtnBg }}; color: {{ $secondaryBtnText }}; border: 1px solid {{ $secondaryBtnBorder }};">{{ $secondaryBtnLabel }}</a>
      {{ end }}
    </div>
  </div>
</section>

---
