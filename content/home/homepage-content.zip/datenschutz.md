---
title: "Datenschutz"
headline: "Datenschutz"
bgClass: "bg-primary"
Color: "var(--sv-offwhite)"
bgImage: "img/sections/_fingerprint.webp" # Add image path if needed
buttonText: "Mehr erfahren"
buttonLink: "/kontakt"
buttonColor: "var(--sv-offwhite)"
buttonBg: "var(--sv-primary-darker)"
---

Gerade bei Gesundheitsdaten ist Datenschutz entscheidend. 

Wir behandeln Ihre Daten vertraulich. Wir verdienen nichts an Therapien und raten Ihnen, was wir auch einem guten Freund raten würden. Ausserdem gehen wir noch einen Schritt weiter und speichern Ihre Daten in einem der sichersten Serverstandorte der Welt, wo nur Sie und Ihr behandelnder Arzt bei SwissVital Zugriff haben. Sie allein entscheiden, wem Sie in welchem Umfang Einsicht gewähren möchten. Falls gewünscht, können Sie auch uns den Zugriff per Knopfdruck entziehen – dann können auch wir Ihre Daten erst wieder sehen, wenn Sie uns erneuten Zugriff gewährt haben.

