---
title: "Bleiben Sie gesund"
headline: "Bleiben Sie gesund"
bgClass: ""
Color: "var(--sv-offwhite)"
bgImage: "img/home/_bleiben-sie-gesund.webp" # Add image path if needed
buttonText: "MRT-Termin"
buttonLink: "/termin"
buttonColor: "var(--sv-offwhite)"
buttonBg: "var(--sv-primary-darker)"
---

Gesund und munter leben: **Das wollen wir alle.**

Das Wichtigste ist Abwechslung für Körper und Geist, Ernährung mit Augenmass und innere Balance. Und dann kommt: **kluge Vorsorge**.

Wenn Sie hier gelandet sind, weil Sie wissen, dass ein MRT für Sie das Richtige ist, bringt der Button Sie zum Termin. Oder Sie lesen erst noch einmal weiter.
