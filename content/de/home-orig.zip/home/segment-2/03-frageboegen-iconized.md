---
background_color: ""
background_image: "var(--bg-lightgrey-warm)"
body_text_alignment: "center"
button_alignment: "center"
button_placement: "content"
grid_layout: "c1/1"
headline_alignment: "center"
id: "wer-profitiert"
image: ""
image-shadow: ""
layout: "section"
primary_button_background: "var(--sv-primary)"
primary_button_border: ""
primary_button_link: ""
primary_button_text: ""
primary_button_text_color: "var(--sv-offwhite)"
secondary_button_background: ""
secondary_button_border: ""
secondary_button_link: ""
secondary_button_text: ""
secondary_button_text_color: ""
text_color: "var(--sv-body-color)"
title: "Auf Ihre Bedürfnisse zugeschnitten"
---

Eine Gesundheitsstrategie ist immer individuell. Damit wir Sie fundiert beraten können, haben wir verschiedene Fragebögen vorbereitet. Suchen Sie sich den heraus, der Ihre Situation am besten beschreibt und beantworten Sie die Fragen. Dann bekommen Sie postwendend per E-Mail eine Empfehlung von einem unserer Präventionsärzte. 

{{< frageboegen >}}
