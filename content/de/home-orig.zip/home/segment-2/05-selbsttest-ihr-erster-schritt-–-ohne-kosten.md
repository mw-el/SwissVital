---
background_color: "var(--sv-offwhite)"
background_image: ""
body_text_alignment: "left"
button_alignment: "center"
button_placement: "content"
grid_layout: "i2/5, c3/5"
headline_alignment: "left"
id: "selbsttest"
image: "img/home/_selbsttest.webp"
image-shadow: "shadow"
layout: "section"
primary_button_background: "var(--sv-primary)"
primary_button_border: ""
primary_button_link: "#selbsttest"
primary_button_text: "Selbsttest starten"
primary_button_text_color: "var(--sv-offwhite)"
secondary_button_background: ""
secondary_button_border: ""
secondary_button_link: ""
secondary_button_text: ""
secondary_button_text_color: ""
text_color: ""
title: "Selbsttest: Ihr erster Schritt – ohne Kosten"
---

Nicht immer ist ein Ganzkörper-MRT erste Wahl. Manchmal sind andere Vorsorgemassnahmen zielsicherer oder wichtiger. Das hängt von Ihrer persönlichen Gesundheitsgeschichte und Ihren Lebensumständen ab.

Die medizinischen Fachgesellschaften haben für verschiedene Vorsorgeuntersuchungen klare Empfehlungen ausgesprochen, die natürlich auf den Einzelfall abgestimmt werden müssen. Bei uns können Sie sich leicht einen Überblick verschaffen, welche Vorsorgestrategie für Sie sinnvoll ist.
