---
title: ""
pre_headline: "" 
type: "pages"


# Bildpositionierung
content_width: 7
image_width: 5
image_position: right

# Standardbild (wird vor Interaktion angezeigt)
image: "/img/sport/_mountainbikers.webp"
image_shadow: "shadow"

# Farbschema
background_color: "var(--sv-moonstone)"
text_color: "var(--sv-body-color)"
accordion_background_color: "var(--sv-offwhite-lighter)"
accordion_content_background_color: "var(--sv-offwhite-lighter)"
accordion_accent_color: "var(--sv-offwhite-darker)"

# Button unter dem Accordion
button_placement: "accordion"
button_alignment: "left"
primary_button_class: "sv-btn-royalblue btn-cap"
primary_button_link: "#termin-buchen"
primary_button_text: "Untersuchung buchen"
partial: "full-bg.html"
---
Vorsorgen statt heilen
# Hilfe für Sportler


{{< spacer >}}

Wir haben viel Erfahrung mit der gesamten Diagnostik des Bewegungsapparats und konnten schon hunderten Sportlern helfen, sich wieder wohl und leistungsfähig zu fühlen.

Wenn Sie Beschwerden plagen, die Sie einfach nicht loswerden, können wir bestimmt Klarheit schaffen. Damit Sie Ihr Training anpassen oder wirksame Therapieoptionen wählen können.  


