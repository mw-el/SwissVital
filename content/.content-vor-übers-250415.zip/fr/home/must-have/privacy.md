---
title: "Politique de confidentialité"
url: "/fr/must-have/politique-de-confidentialite/"
---

{{< readfile file="/content/de/must-have/privacy.md" markdown="true" >}}
