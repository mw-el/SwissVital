---
date: "2025-01-25"
fullimage: "img/standorte/_basel.webp"
image: "img/standorte/basel.webp"
title: "Basel"
---

In Basel werden die Untersuchungen bei unserem Partner durchgeführt. 

**Die Adresse lautet:**

In Basel haben wir mehrere Partner. Die Adresse erhalten Sie mit der Terminbestätigung.
