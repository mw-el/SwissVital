---
date: "2025-01-25"
fullimage: "img/standorte/_bern.webp"
image: "img/standorte/bern.webp"
title: "Bern"
---

In Bern werden die Untersuchungen bei MRI-Bern durchgeführt. 

**Die Adresse lautet:**

Schwanengasse 5/7

3011 Bern
