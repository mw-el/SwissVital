---
date: "2025-01-25"
fullimage: "img/standorte/_zurich.webp"
image: "img/standorte/zurich.webp"
title: "Zürich"
---

In Zürich werden die Untersuchungen in der Praxis Rimed durchgeführt. 

**Die Adresse lautet:**

Mühlebachstrasse 7
8008 Zürich
