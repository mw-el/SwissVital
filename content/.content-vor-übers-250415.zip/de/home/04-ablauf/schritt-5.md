---
title: "Schritt 5: Ihre Nachbesprechung"
weight: 5
image: "/img/home/ablauf/doctor-explains.webp"
---

In einem persönlichen Gespräch klären wir alle offenen Fragen, die sich aus den Untersuchungsergebnissen ergeben haben. Falls nötig, besprechen wir auch mögliche therapeutische Schritte oder Massnahmen, um Ihre Gesundheit zu erhalten oder wiederherzustellen.