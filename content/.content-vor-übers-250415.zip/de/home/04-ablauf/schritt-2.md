---
title: "Schritt 2: Ihre persönliche Vorsorgestrategie"
weight: 2
image: "/img/home/ablauf/vorgespraech.webp"
---

Einer unserer Präventionsärzte schaut sich Ihren Fragebogen an und bespricht mit Ihnen telefonisch die für Sie am besten passende Vorsorgestrategie. Wenn das für Sie passt, müssen Sie nur noch einen Termin festlegen.