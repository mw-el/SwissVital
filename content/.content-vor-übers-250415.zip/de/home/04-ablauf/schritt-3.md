---
title: "Schritt 3: Ihr Check-up in der Swiss Vital Praxis"
weight: 3
image: "/img/home/ablauf/woman-with-scan.webp"
---

Am vereinbarten Termin führen wir die Untersuchungen durch. Falls auch Bluttests vorgesehen sind, empfehlen wir, nüchtern zu erscheinen, um die Ergebnisse nicht zu verfälschen. Was im Detail für Ihre Untersuchung wichtig ist, erklären wir Ihnen in Ruhe vor Ort.