---
title: "Schritt 1: Lassen Sie sich von uns zur Vorsorge beraten"
weight: 1
image: "/img/home/ablauf/man-using-tablet.webp"
---

Zur Vorbereitung haben wir Fragebögen erstellt, die auf unterschiedliche Lebenssituationen abgestimmt sind. Wählen Sie den für Sie passenden Fragebogen aus und senden Sie ihn uns zu. Anschliessend melden wir uns bei Ihnen für die Vereinbarung eines Beratungstermins.