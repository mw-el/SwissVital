---
description: "Vorsorgestrategie für genau festgelegte Risiken"
icon: "person_raised_hand" 
title: "Individuelle Vorsorge"
# ------------------------------------------------------------------------------
# Available button classes (solid & skeleton):
#   sv-btn-red            | sv-btn-red-sk
#   sv-btn-pumpkin        | sv-btn-pumpkin-sk
#   sv-btn-green          | sv-btn-green-sk
#   sv-btn-lightblue      | sv-btn-lightblue-sk
#   sv-btn-moonstone      | sv-btn-moonstone-sk
#   sv-btn-royalblue      | sv-btn-royalblue-sk
#   sv-btn-richblack      | sv-btn-richblack-sk
#   sv-btn-offwhite       | sv-btn-offwhite-sk
#   sv-btn-rose           | sv-btn-rose-sk
#   sv-btn-yellow         | sv-btn-yellow-sk
#
#   btn-cap (Text Grossbuchstaben)
# ------------------------------------------------------------------------------
primary_button_link: "/fragebogen-individuelle-vorsorge/"

weight: "6"
---


