---
description: "Wer einfach nur mit einer einzigen Untersuchung eine breit angelegte Vorsorge möchte, trifft mit einem MRT eine gute Wahl, weil es viele verschiedene Risiken abdeckt."
icon: "sync_saved_locally"
title: "Umfassende Vorsorge"
weight: "6"
---


