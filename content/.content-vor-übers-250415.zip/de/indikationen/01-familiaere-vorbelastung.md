---
description: "Menschen mit einer genetischen Prädisposition zum Beispiel für Krebs oder Aneurysmen möchten sicher gehen, dass bei Ihnen noch alles in Ordnung ist."
icon: "familiar_face_and_zone"
title: "Familiäre Vorbelastung"
weight: "1"
---


