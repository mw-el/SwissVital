---
description: "Das MRT liefert oft (aber nicht immer) gleichwertige oder bessere Bilder als Röntgen und Computertomografie (CT), ohne den Körper mit Strahlen zu belasten."
icon: "airwave"
title: "Strahlenbelastung"
weight: "1"
---


