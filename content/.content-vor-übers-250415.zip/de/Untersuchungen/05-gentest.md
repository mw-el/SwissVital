---
date: "2025-01-25"
fullimage: "img/standorte/_gentest.webp"
image: "img/untersuchungen/gentest.webp"
title: "Analyse genetischer Marker"
---

Hier folgt bald ein Text, in dem wir unsere Gentest-Verfahren erklären.
