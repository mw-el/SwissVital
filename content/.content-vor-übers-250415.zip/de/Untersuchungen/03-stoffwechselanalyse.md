---
date: "2025-01-25"
fullimage: "img/standorte/_stoffwechselanalyse.webp"
image: "img/untersuchungen/stoffwechselanalyse.webp"
title: "Stoffwechselanalyse"
---

Hier folgt bald ein Text, in dem wir unsere Stoffwechselanalyse-Verfahren erklären.
