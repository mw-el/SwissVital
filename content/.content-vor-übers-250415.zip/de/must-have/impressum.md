---
date: "2025-02-08"
title: "Impressum"
url: "/impressum/"
automatic_translate: "no"
---

SwissVital ist ein Unternehmen der Metarad AG  

**Adresse:**  
Metarad AG  
Zürichbergstrasse 146  
8044 Zürich  

**Kontakt:**  
E-Mail: info@swissvital.ch  

**Handelsregistereintrag:**  
CHE-261.208.186  

**Vertretungsberechtigte Person:**  
Nikolaus Löhr  

**Berufsaufsicht:**  
Gesundheitsdirektion des Kantons Zürich  

**Gesamtverantwortliche Leitung:**  
Dr. Nikolaus Löhr, Matthias Wiemeyer  

**Verantwortliche ärztliche Leitung:**  
Dr. Nikolaus Löhr
